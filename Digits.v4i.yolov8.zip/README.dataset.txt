# Digits > 2023-12-21 2:35pm
https://universe.roboflow.com/boris-vin-zbexb/digits-3ttcr

Provided by a Roboflow user
License: CC BY 4.0

